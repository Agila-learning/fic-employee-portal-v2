import{c as o}from"./index-rt0AJCHb.js";const n=o("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);export{n as C};
