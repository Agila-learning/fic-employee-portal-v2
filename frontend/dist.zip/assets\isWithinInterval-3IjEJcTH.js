import{t}from"./index-rt0AJCHb.js";function c(n,e){const i=+t(n),[o,r]=[+t(e.start),+t(e.end)].sort((s,a)=>s-a);return i>=o&&i<=r}export{c as i};
